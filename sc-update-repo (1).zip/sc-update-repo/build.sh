#!/bin/sh
# Build the sc-update .deb:  ./build.sh
set -e
cd "$(dirname "$0")"

VERSION=$(sed -n 's/^Version: //p' pkg/DEBIAN/control)

find pkg -type d -exec chmod 0755 {} +
chmod 0755 pkg/DEBIAN/postinst pkg/DEBIAN/prerm pkg/DEBIAN/postrm
chmod 0755 pkg/bin/sc-update/sc-update
chmod 0644 pkg/DEBIAN/control pkg/DEBIAN/conffiles \
           pkg/lib/systemd/system/sc-update.service pkg/etc/sc-update/config.yaml

dpkg-deb --root-owner-group --build pkg "sc-update_${VERSION}_all.deb"
echo "Built sc-update_${VERSION}_all.deb"
